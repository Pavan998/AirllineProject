package com.example.demo.layer3;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.transaction.annotation.Transactional;
import org.springframework.stereotype.Repository;
import com.example.demo.layer2.Reservation;
import com.example.demo.layer2.Seat;

@Repository
public class ReservationRepositoryImpl implements ReservationRepository {

	@PersistenceContext
    EntityManager entityManager;
	
	@Transactional
	public void addReservation(Reservation rRef) {
		entityManager.persist(rRef);

	}

	@Transactional
	public Reservation findReservation(int tno) {
		
		return entityManager.find(Reservation.class, tno);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Transactional
	public Set<Reservation> findAllReservation() {
		Set<Reservation> tSet;
		Query query = entityManager.createQuery("from Reservation");
		tSet = new HashSet(query.getResultList());
		return tSet;
		
	}

	@Transactional
	public void modifyReservation(Reservation rRef) {
		entityManager.merge(rRef);
		
	}

	@Transactional
	public void removeReservation(int tno) {
		Reservation reseObj = entityManager.find(Reservation.class,tno);
		entityManager.remove(reseObj);

	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Transactional
	public Set<Object> findTicketDetails(int tno) {
		Set<Object> tSet;
		
		
		Query query = entityManager.createNativeQuery("select * from reservation where ticketno = "+tno,Reservation.class);
		tSet = new HashSet(query.getResultList());
		
		Query query2 = entityManager.createNativeQuery("select * from seats where ticketno = "+tno,Seat.class);
		tSet.addAll( new HashSet(query2.getResultList()));
		
		return tSet;
	}

}
