package com.example.demo.layer5;


import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.layer2.Flight;
import com.example.demo.layer4.FlightService;
import com.example.demo.layer4.exceptions.FlightAlreadyExistException;
import com.example.demo.layer4.exceptions.FlightNotFoundException;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class FlightController {

	@Autowired
	FlightService flightServ;
	
	@GetMapping(path="/getFlight/{myFlightId}")
	@ResponseBody
	public ResponseEntity<Flight> getFlight(@PathVariable("myFlightId") int flightId){
		System.out.println("Flight Controller....Understanding client and talking to service layer...");
		Flight flightObj =null;
		
		try {
			flightObj = flightServ.findFlightService(flightId);
		} catch (FlightNotFoundException e) {
			
			e.printStackTrace();
		}
		
		if(flightObj==null)
		{ return ResponseEntity.notFound().build();
		
		}
		else {
			return ResponseEntity.ok(flightObj);
		} 
	}
	
	
	@GetMapping(path="/getAllFlights")
	@ResponseBody
	public Set<Flight> getAllFlights(){
		System.out.println("Flight Controller....Understanding client and talking to service layer...");
		Set<Flight> flightSet = flightServ.findAllFlightService();
		return flightSet;
		
	}
	@PostMapping(path="/addFlight")
	public String addFlight(@RequestBody Flight flight) {
		System.out.println("Flight Controller....Understanding client and talking to service layer...");
		String stmsg=null;
		Flight flightObj =new Flight();
		flightObj.setArrivaltime(flight.getArrivaltime());
		flightObj.setDeparturetime(flight.getDeparturetime());
		flightObj.setDestination(flight.getDestination());
		flightObj.setDurationinhrs(flight.getDurationinhrs());
		flightObj.setFlightname(flight.getFlightname());
		flightObj.setFlightstatus(flight.getFlightstatus());
		flightObj.setSource(flight.getSource());
		flightObj.setTotalseats(flight.getTotalseats());
		
		try {
			stmsg=flightServ.addFlightService(flightObj);
		} catch (FlightAlreadyExistException e) {
			
			e.printStackTrace();
			return e.getMessage();
			
		}
		
		return stmsg;
	}
	
	@PutMapping(path="/modifyFlight")
	public String modifyFlight(@RequestBody Flight flight) {
		System.out.println("Flight Controller....Understanding client and talking to service layer...");
		String stmsg=null;
		
		try {
			stmsg= flightServ.modifyFlightService(flight);
		} catch (FlightNotFoundException e) {
			
			e.printStackTrace();
			return e.getMessage();
		}
				
		return stmsg;
	}
	
	@DeleteMapping(path="/deleteFlight/{myfno}")
	@ResponseBody
	public String removeSignup(@PathVariable("myfno") int flightNo)throws FlightNotFoundException {
		System.out.println("Flight Controller....Understanding client and talking to service layer...");
		 String stmsg = null;
		try {
			stmsg = flightServ.removeFlightService(flightNo);
		} 
		catch (FlightNotFoundException e) {
			e.printStackTrace();
			return e.getMessage();
		}
		catch(Exception e) {
			e.printStackTrace();
			return "some issue";
		}
		  return stmsg;
	}
	
	@GetMapping(path="/getAllFlights/{mysrc},{mydest}")
	@ResponseBody
	public Set<Flight> getAllFlight(@PathVariable("mysrc")String src,@PathVariable("mydest")
	String dest){
		
		/*
		 * Date jd=null; SimpleDateFormat sd = new SimpleDateFormat("dd-MM-yyy"); try {
		 * java.util.Date uDate = sd.parse(date); jd = new Date(uDate.getTime());
		 * System.out.println("After convertion: "+jd); } catch (ParseException e) {
		 * e.printStackTrace(); }
		 */
		
		Set<Flight> flightSet = flightServ.findAllFlightService(src,dest);
		
		return flightSet;
	}
	
	
}