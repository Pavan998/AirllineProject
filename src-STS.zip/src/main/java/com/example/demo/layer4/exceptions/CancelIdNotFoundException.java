  
package com.example.demo.layer4.exceptions;



@SuppressWarnings("serial")
public class CancelIdNotFoundException extends Throwable{
	public CancelIdNotFoundException(String msg) {
		super(msg);
	}
}