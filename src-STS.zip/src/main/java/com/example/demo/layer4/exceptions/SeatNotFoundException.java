package com.example.demo.layer4.exceptions;

@SuppressWarnings("serial")
public class SeatNotFoundException extends Exception
{
	public SeatNotFoundException(String message) 
	{
		super(message);
	
	}

}
