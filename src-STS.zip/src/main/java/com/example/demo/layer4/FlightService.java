package com.example.demo.layer4;

import java.util.Set;
import org.springframework.stereotype.Service;
import com.example.demo.layer2.Flight;
import com.example.demo.layer4.exceptions.FlightAlreadyExistException;
import com.example.demo.layer4.exceptions.FlightNotFoundException;

@Service
public interface FlightService {
	String addFlightService(Flight fRef) throws FlightAlreadyExistException;   //C - add/create
	Flight findFlightService(int flightNo)throws FlightNotFoundException;     //R - find/reading
	Set<Flight> findAllFlightService();     //R - find all/reading all
	String modifyFlightService(Flight fRef)throws FlightNotFoundException; //U - modify/update
	String removeFlightService(int flightNo)throws FlightNotFoundException; //D - remove/delete
	
	Set<Flight> findAllFlightService(String src,String dest);
}