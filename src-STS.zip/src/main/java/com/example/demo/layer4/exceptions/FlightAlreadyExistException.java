package com.example.demo.layer4.exceptions;

@SuppressWarnings("serial")
public class FlightAlreadyExistException extends Throwable {

	public FlightAlreadyExistException(String msg) {
		super(msg);
	}

}
