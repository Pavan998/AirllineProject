package com.example.demo.layer4;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.layer2.Flight;
import com.example.demo.layer3.FlightRepository;
import com.example.demo.layer4.exceptions.FlightAlreadyExistException;
import com.example.demo.layer4.exceptions.FlightNotFoundException;

@Service
public class FlightServiceImpl implements FlightService {
	
	@Autowired
	FlightRepository flightRepo;
	
	@Override
	public String addFlightService(Flight fRef)throws FlightAlreadyExistException {
		System.out.println("Flight Service....Some scope of bussiness logic here...");
		try {
			flightRepo.addFlight(fRef);
		} catch (Exception e) {
			throw new FlightAlreadyExistException("Flight Already Exist");
		}
		return "Flight added Successfully";
	}

	@Override
	public Flight findFlightService(int flightNo)throws FlightNotFoundException {
		System.out.println("Flight Service....Some scope of bussiness logic here...");
			Flight flight; 

		 flight = flightRepo.findFlight(flightNo);
		if(flight==null) {
			throw new FlightNotFoundException("Flight Not Found");
		}
		 return flight;
	}

	@Override
	public Set<Flight> findAllFlightService() {
		System.out.println("Flight Service....Some scope of bussiness logic here...");
		
		return flightRepo.findAllFlight();
	}

	@Override
	public String modifyFlightService(Flight flight)throws FlightNotFoundException {
		System.out.println("Flight Service....Some scope of bussiness logic here...");
		
		Flight flightObj = flightRepo.findFlight(flight.getFlightid());
		if(flightObj!=null)
		{flightRepo.modifyFlight(flight);}
		else {
			throw new FlightNotFoundException("Flight Not Found");
		}
		return "Flight Modified Successfully";
	}

	@Override
	public String removeFlightService(int flightNo)throws FlightNotFoundException {
		System.out.println("Flight Service....Some scope of bussiness logic here...");
		Flight flightObj = flightRepo.findFlight(flightNo);
		String smsg=null;
		if(flightObj!=null) {
		smsg = flightRepo.removeFlight(flightNo);	
		}
		else {
			throw new FlightNotFoundException("Flight Not Found");
		}
		return smsg;
	}

	@Override
	public Set<Flight> findAllFlightService(String src, String dest) {
		System.out.println("Flight Service....Some scope of bussiness logic here...");
		
		return flightRepo.findFlight(src,dest);
	}

}