import { Component, OnInit } from '@angular/core';
import { NgModel } from '@angular/forms';
import { Router } from '@angular/router';
import { flight } from '../flight';
import { FlightService } from '../flight.service';
import { FlightsearchComponent } from '../flightsearch/flightsearch.component';


@Component({
  selector: 'app-flight-select',
  templateUrl: './flight-select.component.html',
  styleUrls: ['./flight-select.component.css']
})
export class FlightSelectComponent implements OnInit {
  str:any|undefined;
  tempAry:Array<flight>=[];
  status:any|undefined;
  isLoggedIn=(status!="false");
  buttonLable="LOGIN";
  id=0;
  price=0;
def:any|undefined;
economy(id:number){
  this.price=3000;
  sessionStorage.setItem("id",JSON.stringify(id));
  sessionStorage.setItem("price",JSON.stringify(this.price));
  if(this.isLoggedIn==true){
  this.router.navigate(["/seat"]);}
  else{
    alert("Please login");
    this.router.navigate(["/user"]);
  }
}

bussiness(id:number){
  this.price=5000;
  sessionStorage.setItem("id",JSON.stringify(id));
  sessionStorage.setItem("price",JSON.stringify(this.price));
  if(this.isLoggedIn==true){
    this.router.navigate(["/seat"]);}
    else{
      alert("Please login");
      this.router.navigate(["/user"]);
    }
}


  isLoggedInFun(){
    if(this.isLoggedIn==true){
      confirm("Are you sure to logout ??");
         this.buttonLable="LOGIN";
         sessionStorage.setItem("btn",JSON.stringify(this.buttonLable));
         this.isLoggedIn=false;
         sessionStorage.setItem("status",JSON.stringify(this.isLoggedIn));
    }
    else{
     this.router.navigate(["/user"]);
      this.buttonLable="LOGOUT";
      sessionStorage.setItem("btn",JSON.stringify(this.buttonLable));
      this.isLoggedIn=true;
      sessionStorage.setItem("status",JSON.stringify(this.isLoggedIn));
    }
  }




 
  constructor(private fs:FlightService,private router: Router) { }
  ngOnInit(): void {
    this.str=sessionStorage.getItem("flightDetails");
    this.tempAry=JSON.parse(this.str);
    this.def=sessionStorage.getItem("btn");
    this.buttonLable=JSON.parse(this.def);
    this.status=sessionStorage.getItem("status");
    this.isLoggedIn=JSON.parse(this.status);
  }

}
