export class Signup{
    userid : number|undefined;
    title :string|undefined;
    firstname : string |undefined;
    lastname : string |undefined;
    dateofbirth :Date|undefined;
    phoneno : number|undefined;
    emailaddr : string|undefined;
    password :string|undefined;
    confirmpassword : string|undefined;
}