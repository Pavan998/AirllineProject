import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { AdminComponent } from './admin/admin.component';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FlightSelectComponent } from './flight-select/flight-select.component';
import { FlightsearchComponent } from './flightsearch/flightsearch.component';
import { HomeLoginComponent } from './home-login/home-login.component';
import { SignupComponent } from './signup/signup.component';
import { UserComponent } from './user/user.component';
import { SeatComponent } from './seat/seat.component';
import { PaymentComponent } from './payment/payment.component';
import {HttpClientModule} from '@angular/common/http'
import {HttpClient} from '@angular/common/http';
import { DashboardComponent } from './dashboard/dashboard.component';
import { CancelTicketComponent } from './cancel-ticket/cancel-ticket.component'



@NgModule({
  declarations: [
    AppComponent,
    UserComponent,
    AdminComponent,
    SignupComponent,
    FlightsearchComponent,
    FlightSelectComponent,
    HomeLoginComponent,
    SeatComponent,
    PaymentComponent,
    DashboardComponent,
    CancelTicketComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  exports:[
    FlightSelectComponent
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
