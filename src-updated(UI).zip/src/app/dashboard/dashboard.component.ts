import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FlightService } from '../flight.service';
import { Signup } from '../Signup';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {


stat:any|undefined;
  isLoggedIn=false;
  signup:Signup=new Signup();
  constructor(private router:Router, private fs:FlightService) { }

  ngOnInit(): void {
    this.stat=sessionStorage.getItem("status");
    this.isLoggedIn=JSON.parse(this.stat);
  }

ticket(){
  if(this.isLoggedIn==false){
    alert("please Login");
    this.router.navigate(["/user"]);
  }
  else{
this.router.navigate(["/cancel"]);
  }
}

findUser(){
  if(this.isLoggedIn==false){
    alert("please Login");
    this.router.navigate(["/user"]);
  }
  else{
  this.router.navigate(["/userdetails"]);
  }
}

}
