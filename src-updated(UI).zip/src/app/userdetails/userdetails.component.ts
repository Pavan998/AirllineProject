import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FlightService } from '../flight.service';
import { Signup } from '../Signup';

@Component({
  selector: 'app-userdetails',
  templateUrl: './userdetails.component.html',
  styleUrls: ['./userdetails.component.css']
})
export class UserdetailsComponent implements OnInit {
  userid:any|undefined;
  uid=0;
  mysignup1:Signup=new Signup();
  constructor(private router:Router, private fs:FlightService) { }

  ngOnInit(): void {
   
  }


  finduser(){
    this.userid=sessionStorage.getItem("uid");
    this.uid=JSON.parse(this.userid);
    this.fs.findUserService(this.uid).subscribe((data:Signup)=>{
      console.log(data);
      this.mysignup1=data;
    },(err: any)=>{
      console.log(err);
    });
  }
  

}
