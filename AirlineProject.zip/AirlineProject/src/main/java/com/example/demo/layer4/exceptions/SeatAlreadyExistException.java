package com.example.demo.layer4.exceptions;

@SuppressWarnings("serial")
public class SeatAlreadyExistException extends Exception
{ 
	public SeatAlreadyExistException(String message)
	{
		super(message);
	}
    
}