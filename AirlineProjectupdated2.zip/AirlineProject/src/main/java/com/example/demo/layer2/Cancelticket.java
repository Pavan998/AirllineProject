package com.example.demo.layer2;


import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the CANCELTICKET database table.
 * 
 */
@Entity
@Table(name="CANCELTICKET")
@NamedQuery(name="Cancelticket.findAll", query="SELECT c FROM Cancelticket c")
public class Cancelticket  {
	
	@Id
	private long cancelid;
	
	@Temporal(TemporalType.TIMESTAMP)
	private Date canceldate;
	
	private Double refundamount;

	private String refundstatus;

	//bi-directional many-to-one association to Reservation
	@OneToOne(cascade=CascadeType.ALL)
	@MapsId
	@JoinColumn(name="TICKETNO")
	private Reservation reservation;

	public Cancelticket() {
		super();
		System.out.println("CancelTicket contr()......");
	}

	public Date getCanceldate() {
		return this.canceldate;
	}

	public void setCanceldate(Date canceldate) {
		this.canceldate = canceldate;
	}

	public long getCancelid() {
		return this.cancelid;
	}

	public void setCancelid(long cancelid) {
		this.cancelid = cancelid;
	}

	public Double getRefundamount() {
		return this.refundamount;
	}

	public void setRefundamount(Double refundamount) {
		this.refundamount = refundamount;
	}

	public String getRefundstatus() {
		return this.refundstatus;
	}

	public void setRefundstatus(String refundstatus) {
		this.refundstatus = refundstatus;
	}

	public Reservation getReservation() {
		return this.reservation;
	}

	public void setReservation(Reservation reservation) {
		this.reservation = reservation;
	}

}