import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminComponent } from './admin/admin.component';
import { CancelTicketComponent } from './cancel-ticket/cancel-ticket.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { FlightSelectComponent } from './flight-select/flight-select.component';
import { ForgotComponent } from './forgot/forgot.component';
import { HomeLoginComponent } from './home-login/home-login.component';
import { PaymentComponent } from './payment/payment.component';
import { SeatComponent } from './seat/seat.component';
import { SignupComponent } from './signup/signup.component';
import { UserComponent } from './user/user.component';


const routes: Routes = [
  { path:'',redirectTo:"/home",pathMatch:'full'},
  {path:"home",component:HomeLoginComponent},
  {path:"user",component:UserComponent},
  {path:"admin",component:AdminComponent},
  {path:"signup",component:SignupComponent},
  {path:"forgot",component:ForgotComponent},
  {path:"select",component:FlightSelectComponent},
  {path:"seat",component:SeatComponent},
  {path:"payment",component:PaymentComponent},
  {path:"cancel",component:CancelTicketComponent}
 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
