import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cancel-ticket',
  templateUrl: './cancel-ticket.component.html',
  styleUrls: ['./cancel-ticket.component.css']
})
export class CancelTicketComponent implements OnInit {


status="";
sn="";
isDisabledA1=true;
isDisabledB1=true;
isDisabledC1=true;
isDisabledD1=true;
isDisabledE1=true;
isDisabledF1=true;

isDisabledA2=true;
isDisabledB2=true;
isDisabledC2=true;
isDisabledD2=true;
isDisabledE2=true;
isDisabledF2=true;

isDisabledA3=true;
isDisabledB3=true;
isDisabledC3=true;
isDisabledD3=true;
isDisabledE3=true;
isDisabledF3=true;

isDisabledA4=true;
isDisabledB4=true;
isDisabledC4=true;
isDisabledD4=true;
isDisabledE4=true;
isDisabledF4=true;

isDisabledA5=true;
isDisabledB5=true;
isDisabledC5=true;
isDisabledD5=true;
isDisabledE5=true;
isDisabled=true;

cancel(sn:string){
  if(sn=="1A"){
    this.isDisabledA1=false;
    sessionStorage.setItem("bookA1",JSON.stringify(this.isDisabledA1));
  }

if(sn=="2A"){
    this.isDisabledA2=false;
    sessionStorage.setItem("bookA2",JSON.stringify(this.isDisabledA2));
  }

if(sn=="3A"){
    this.isDisabledA3=false;
    sessionStorage.setItem("bookA3",JSON.stringify(this.isDisabledA3));
  }

if(sn=="4A"){
    this.isDisabledA4=false;
    sessionStorage.setItem("bookA4",JSON.stringify(this.isDisabledA4));
  }

if(sn=="5A"){
    this.isDisabledA5=false;
    sessionStorage.setItem("bookA5",JSON.stringify(this.isDisabledA5));
  }

if(sn=="1B"){
    this.isDisabledB1=false;
    sessionStorage.setItem("bookB1",JSON.stringify(this.isDisabledB1));
  }

if(sn=="2B"){
    this.isDisabledB2=false;
    sessionStorage.setItem("bookB2",JSON.stringify(this.isDisabledB2));
  }

if(sn=="3B"){
    this.isDisabledB3=false;
    sessionStorage.setItem("bookB3",JSON.stringify(this.isDisabledB3));
  }

if(sn=="4B"){
    this.isDisabledB4=false;
    sessionStorage.setItem("bookB4",JSON.stringify(this.isDisabledB4));
  }

if(sn=="5B"){
    this.isDisabledB5=false;
    sessionStorage.setItem("bookB5",JSON.stringify(this.isDisabledB5));
  }

if(sn=="1C"){
    this.isDisabledC1=false;
    sessionStorage.setItem("bookC1",JSON.stringify(this.isDisabledC1));
  }

if(sn=="2C"){
    this.isDisabledC2=false;
    sessionStorage.setItem("bookC2",JSON.stringify(this.isDisabledC2));
  }

if(sn=="3C"){
    this.isDisabledC3=false;
    sessionStorage.setItem("bookC3",JSON.stringify(this.isDisabledC3));
  }

if(sn=="4C"){
    this.isDisabledA4=false;
    sessionStorage.setItem("bookC4",JSON.stringify(this.isDisabledC4));
  }

if(sn=="5C"){
    this.isDisabledC5=false;
    sessionStorage.setItem("bookC5",JSON.stringify(this.isDisabledC5));
  }

if(sn=="1D"){
    this.isDisabledD1=false;
    sessionStorage.setItem("bookD1",JSON.stringify(this.isDisabledD1));
  }

if(sn=="2D"){
    this.isDisabledD2=false;
    sessionStorage.setItem("bookD2",JSON.stringify(this.isDisabledD2));
  }

if(sn=="3D"){
    this.isDisabledD3=false;
    sessionStorage.setItem("bookD3",JSON.stringify(this.isDisabledD3));
  }

if(sn=="4D"){
    this.isDisabledD4=false;
    sessionStorage.setItem("bookD4",JSON.stringify(this.isDisabledD4));
  }

if(sn=="5D"){
    this.isDisabledD5=false;
    sessionStorage.setItem("bookD5",JSON.stringify(this.isDisabledD5));
  }

if(sn=="1E"){
    this.isDisabledE1=false;
    sessionStorage.setItem("bookE1",JSON.stringify(this.isDisabledE1));
  }

if(sn=="2E"){
    this.isDisabledE2=false;
    sessionStorage.setItem("bookE2",JSON.stringify(this.isDisabledE2));
  }

if(sn=="3E"){
    this.isDisabledE3=false;
    sessionStorage.setItem("bookE3",JSON.stringify(this.isDisabledE3));
  }

if(sn=="4E"){
    this.isDisabledE4=false;
    sessionStorage.setItem("bookE4",JSON.stringify(this.isDisabledE4));
  }

if(sn=="5E"){
    this.isDisabledE5=false;
    sessionStorage.setItem("bookE5",JSON.stringify(this.isDisabledE5));
  }

if(sn=="1F"){
    this.isDisabledF1=false;
    sessionStorage.setItem("bookF1",JSON.stringify(this.isDisabledF1));
  }

if(sn=="2F"){
    this.isDisabledF2=false;
    sessionStorage.setItem("bookF2",JSON.stringify(this.isDisabledF2));
  }

if(sn=="3F"){
    this.isDisabledF3=false;
    sessionStorage.setItem("bookF3",JSON.stringify(this.isDisabledF3));
  }

if(sn=="4F"){
    this.isDisabledF4=false;
    sessionStorage.setItem("bookF4",JSON.stringify(this.isDisabledF4));
  }
  
  if(sn=="5F"){
    this.isDisabled=false;
    sessionStorage.setItem("book",JSON.stringify(this.isDisabled));
  }

  alert("ticket cancelled");
  this.status="TICKET CANCELLED";
}
  constructor() { }

  ngOnInit(): void {
  }

}
