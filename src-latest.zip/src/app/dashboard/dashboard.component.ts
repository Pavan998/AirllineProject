import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FlightService } from '../flight.service';
import { Signup } from '../Signup';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

uid=0;
userid:any|undefined;
  isLoggedIn=false;
  signup:Signup=new Signup();
  constructor(private router:Router, private fs:FlightService) { }

  ngOnInit(): void {
    this.userid=sessionStorage.getItem("uid");
    this.uid=JSON.parse(this.userid);

  }

ticket(){
this.router.navigate(["/cancel"]);
}


findUser(uId:number){
  this.fs.findUserService(uId).subscribe((data:Signup)=>{
   console.log(data);
   this.signup=data;
},(err: any)=>{
  console.log(err);
});
}

}
