import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FlightService } from '../flight.service';
import { Signup } from '../Signup';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  myLogin:Signup = new Signup();
  constructor(private sg:FlightService,private router: Router) { }
  ngOnInit(): void {
  }
  userid=0;
  Pass="";
  passType: string = 'password';
  signup:Signup =new Signup();
  isLoggedIn=false;
  button="LOGOUT";
  findUserAthentication(uId:number,pass:string){
    this.sg.findUserService(uId).subscribe((data:Signup)=>{
     console.log(data);
     this.signup=data;
     this.userid=uId;
     sessionStorage.setItem("uid",JSON.stringify(this.userid));
     if(this.signup.password==pass)
     {
      this.isLoggedIn=true;
      sessionStorage.setItem("status",JSON.stringify(this.isLoggedIn));
      sessionStorage.setItem("btn",JSON.stringify(this.button));
      alert("Logged-In Successfully");
     }
     else
     {
      alert(" Failed To Login,Recheck Details ");
     }
  },(err: any)=>{
    console.log(err);
  });
  this.router.navigate(["/select"]);
}

 myFunction() {
  if(this.passType== 'password'){
    this.passType= 'text'
    }else{
    this.passType== 'password'
    }
}



}

