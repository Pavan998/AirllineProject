export class flight
{
    flightid:number|undefined;
    flightname:string|undefined;
    source:string|undefined;
    destination:string|undefined;
    totalseats:number|undefined;
    departuretime:string|undefined;
    arrivaltime:string|undefined;
    durationinhrs:number|undefined;
    flightstatus:number|undefined;
   
}