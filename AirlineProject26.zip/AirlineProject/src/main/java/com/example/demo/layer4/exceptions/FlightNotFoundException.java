package com.example.demo.layer4.exceptions;

@SuppressWarnings("serial")
public class FlightNotFoundException extends Throwable {

	public FlightNotFoundException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}

}
