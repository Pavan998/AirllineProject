  
package com.example.demo.layer4.exceptions;



@SuppressWarnings("serial")
public class AdminNotFoundException extends Throwable{
	public AdminNotFoundException(String msg) {
		super(msg);
	}
}