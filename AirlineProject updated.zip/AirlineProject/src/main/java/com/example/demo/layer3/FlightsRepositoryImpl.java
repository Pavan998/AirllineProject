package com.example.demo.layer3;


import java.util.Set;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;


import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.layer2.Flight;

@Repository
public class FlightsRepositoryImpl implements FlightsRepository
{


	@PersistenceContext
	 EntityManager entityManager;
	@Transactional
	public void addFlight(Flight fRef) {


		entityManager.persist(fRef);
	}

	@Transactional
	public Flight findFlight(int flightNo) {
	
		
		System.out.println("Flights repo....NO scope of bussiness logic here...");
		/*
		 * Flights flightObj = entityManager.find(Flights.class, flightNo);
		 * System.out.println(flightObj);
		 */
		return entityManager.find(Flight.class, flightNo);
		
	}

	@Transactional
	public void modifyFlight(Flight fRef) {
		// TODO Auto-generated method stub
		
		
		
	}

	@Transactional
	public void removeFlight(int flightNo) {
		// TODO Auto-generated method stub
		
	}

	@Transactional
	public Set<Flight> findFlight() {
		// TODO Auto-generated method stub
		return null;
	}

}
