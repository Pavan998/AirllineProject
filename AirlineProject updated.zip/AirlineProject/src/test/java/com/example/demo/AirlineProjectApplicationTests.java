package com.example.demo;



import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.layer2.Flight;
import com.example.demo.layer3.FlightsRepository;

@SpringBootTest
class AirlineProjectApplicationTests {

	
	@Autowired
	FlightsRepository flightsRepo;
	@Test
	void contextLoads() {
	//Set<Employee2> empSet = empRepo.findEmployeesByDeptno(30);
	
	Flight f=flightsRepo.findFlight(101);
	System.out.println(f.getFlightid());
	System.out.println(f.getFlightname());
	System.out.println(f.getSource());
	
	System.out.println(f.getDestination());
	System.out.println(f.getTotalseats());
	System.out.println(f.getDeparturetime());
	System.out.println(f.getArrivaltime());
	System.out.println(f.getDurationinhrs());
	
	
	System.out.println("-----------------");
}
	
}

	
	
	
	
