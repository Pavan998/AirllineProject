export class flight
{
    flightid:number|undefined;
    flightname:string|undefined;
    source:string|undefined;
    desination:string|undefined;
    totalseats:number|undefined;
    departuretime:string|undefined;
    arivaltime:string|undefined;
    durationinhrs:number|undefined;
    flightstatus:number|undefined;
   
}