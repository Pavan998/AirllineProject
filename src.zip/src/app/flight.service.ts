import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { flight } from './flight';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class FlightService {

  constructor() { }
  // private myHttp: HttpClient
  
// findFlightsBySrcAndDestService(src: string,dest:string,date:string): Observable<any>{
//   return this.myHttp.get<any>("http://localhost:8080/getAllFlights/"+src+","+dest+","+date);

//}




}
