import { Component, OnInit } from '@angular/core';
import { flight } from '../flight';
import { FlightService } from '../flight.service';


@Component({
  selector: 'app-flightsearch',
  templateUrl: './flightsearch.component.html',
  styleUrls: ['./flightsearch.component.css']
})
export class FlightsearchComponent implements OnInit {
 src="HYDERABAD";
 dest="PUNE";
 date="12-05-2021";
  constructor(private fs:FlightService ) { }
  

  ngOnInit(): void {
  }

   tempFlight: flight[]|undefined;
   findFlightsBySrcAndDest(src: string,dest:string,date:string){
     this.fs.findFlightsBySrcAndDestService(src,dest,date).subscribe((data:flight[])=>{
      console.log(data);
    this.tempFlight=data;
       console.log(data);
     },(err)=> {
      console.log(err);
       
       });
 }

 /*this.bookService.findBooksByCategory(category)
               
                .subscribe((data: Book[]) => {
                    this.books = data;
                }, (err) => {
                    console.log(err);
                });*/

}
